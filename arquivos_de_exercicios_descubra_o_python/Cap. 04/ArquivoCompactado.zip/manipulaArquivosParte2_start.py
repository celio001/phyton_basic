#
# Exemplos de como trabalhar com arquivos
#
import os
from os import path
import shutil
from shutil import make_archive
from zipfile import ZipFile

def CriaZipModo1():
    shutil.make_archive('ArquivoCompactado', 'zip', 'C:\\Users\\User\\Documents\\ESTUDOS LINKEDIN\\arquivos_de_exercicios_descubra_o_python\\Cap. 04')

CriaZipModo1()